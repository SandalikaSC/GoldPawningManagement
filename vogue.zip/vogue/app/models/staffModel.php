<?php
class staffModel extends Database{
    public function getStaffMember(){
        $sql = 'select id, concat(fName,lName) as Name, role, date from staff';
        $this->query($sql);
        $result = $this->resultSet();
        if($this->rowCount()>0){
            return $result;
        }else{
            return 0;
        }
    }

}
?>
<?php
class UserModel extends Database{
    public function getUser($email){
        $sql = 'select email, password FROM user where email=? limit 1';
        $this->query($sql);
        $this->bind(1,$email);
        $result = $this->single();
        return $result;
    }

}
?>
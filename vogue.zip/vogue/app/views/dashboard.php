<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff</title>
    <link rel="stylesheet" href="<?php echo URL_ROOT?>public/stylesheets/main_dashboard.css">
</head>
<body>
    <div class="page">
        <div class="left" id="panel">
            <div class="profile">
               <div class="profile-pic">
                  <a href="url"><img src="<?php echo URL_ROOT?>public/img/image 1.png" alt=""></a>
               </div>
               <div class="name">
                   <p>Thimeth Imesha</p>
               </div>
            </div>
            <div class="btn-set">
                <a class="dash" href="url">
                   <img src="<?php echo URL_ROOT?>public/img/golden_dashboard.png" alt="">
                   <p>Dashboard</p>
                </a>
                <a href="url">
                   <img src="<?php echo URL_ROOT?>public/img/locker.png" alt="">
                   <p>Locker</p>
                </a>
                <a href="url">
                   <img src="<?php echo URL_ROOT?>public/img/pawned.png" alt="">
                   <p>Pawned Articles</p>
                </a>
                <a href="url">
                   <img src="<?php echo URL_ROOT?>public/img/auction.png" alt="">
                   <p>Auction</p>
                </a>
                <a  href="<?php echo URL_ROOT?>staff">
                   <img src="<?php echo URL_ROOT?>public/img/staff.png" alt="">
                   <p>Staff</p>
                </a>
            </div>
            <div class="lgout">
                <a href="logout.php">Logout</a>
            </div>
        </div>
        <div class="right">
            <div class="right-heading">
                <div class="right-side">
                    <div class="bars" id="bars">
                    <img src="<?php echo URL_ROOT?>public/img/icons8-bars-48.png" alt="bars">
                    </div>
                    <h1>Dashboard</h1>
                </div>
                <img class="vogue" src="<?php echo URL_ROOT?>public/img/Panem Finance Inc 3.png" alt="logo">
            </div>
            <div class="inside-page">
               
            </div>
        </div>
    </div>
</body>
<script>
    let bars = document.getElementById("bars");
    let panel = document.getElementById("panel");

    bars.addEventListener("click",()=>{
        panel.classList.toggle("hide");
    })    
</script>
</html>
            
                    
                    
<?php
   class Staff extends Controller{
    public function index(){
        isLoggedIn();
        $staff = $this->model("staffModel");
        $result = $staff->getStaffMember();
        $this->view("staff_dashboard",$result);
    }

    
    public function addNew(){
      isLoggedIn();
      $this->view("add_employee");
    }

    // public function 
  }
?>
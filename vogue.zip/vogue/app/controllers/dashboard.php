<?php
class dashboard extends controller{
    
     public function index(){

        isLoggedIn();
        $this->view("dashboard");
     }
}
?>
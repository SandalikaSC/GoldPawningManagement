<?php
  session_start();

  function isLoggedIn(){
    if(!isset($_SESSION['user'])){
      redirect('login');
    } 
  }

?>
<?php

use LDAP\Result;

class staffModel extends Database{
    public function getStaffMember(){
        $sql = 'select id, concat(fName," ",lName) as Name, role, timestamp as date from staff';
        $this->query($sql);
        $result = $this->resultSet();
        if($this->rowCount()>0){
            return $result;
        }else{
            return 0;
        }
    }

    private function getStaffId($role){
        $sql="select id from staff where role=? order by id desc limit 1";
        $this->query($sql);
        $this->bind(1,$role);
        $result = $this->single();


        if(empty($result)){
            switch ($role) {
                case 'Pawning Officer':
                    return 'S000';
                    break;

                case 'Vault Keeper':
                    return 'V000';
                    break;
                    
                case 'Gold Appraiser':
                    return 'G000';
                    break;      
            }
        }else{
            return $result->id;
        }
    }

    public function addStaffMember($fName,$lName,$nic,$dob,$lane1,$lane2,$lane3,$mob,$home,$email,$role)
    {
        $id=$this->getStaffId($role);
        var_dump(++$id);
        $sql = 'insert into staff(id, fName, lName, nic, dob, lane1, lane2, lane3, telNo, lanNo, email, role) values (?,?,?,?,?,?,?,?,?,?,?,?)';
        $this->query($sql);

        $this->bind(1,$id);
        $this->bind(2,$fName);
        $this->bind(3,$lName);
        $this->bind(4,$nic);
        $this->bind(5,$dob);
        $this->bind(6,$lane1);
        $this->bind(7,$lane2);
        $this->bind(8,$lane3);
        $this->bind(9,$mob);
        $this->bind(10,$home);
        $this->bind(11,$email);
        $this->bind(12,$role);

        return $this->execute();
    }

    public function viewStaffMember($id){
        $sql="select * from staff where id= ? limit 1";
        $this->query($sql);
        $this->bind(1,$id);
        $result = $this->single();
        return $result;
    }
}
?>
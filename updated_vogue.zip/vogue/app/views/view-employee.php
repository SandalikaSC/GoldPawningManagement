<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo URL_ROOT?>public/stylesheets/view_employee.css" />
  </head>

  <body>
    <div class="page">
      <div class="right">
        <div class="right-heading">
          <div class="right-side">
            <div class="back" id="back">
              <a href="url"><img src="<?php echo URL_ROOT ?>public/img/backbutton.png" alt="back" /></a>
            </div>
            <h1><?php echo $data->id ?></h1>
          </div>
          <img class="vogue" src="<?php echo URL_ROOT ?>public/img/Panem Finance Inc 3.png" alt="logo" />
        </div>
        <div class="content-add-new-page">
          <!--  -->
          <form action="./staff/setStaffMember" method="POST">
            <section class="section_left">
              <section class="big-form">
                <img src="<?php echo URL_ROOT ?>public/img/image 1.png" alt="photo" />

                <div class="form-group">
                  <label for="fName"><b>First Name:</b></label>
                  <label><?php echo $data->fName ?></label>
                </div>
                <div class="form-group">
                  <label for="lName"><b>Last Name:</b></label>
                  <label><?php echo $data->lName ?></label>
                </div>
                <div class="form-group">
                  <label for="nic"><b>NIC:</b></label>
                  <label><?php echo $data->nic ?></label>
                </div>
                <div class="form-group">
                  <label for="dob"><b>Date of Birth:</b></label>
                  <label><?php echo $data->dob ?></label>
                </div>
                <div class="form-group">
                  <label for="lane1"><b>Address Lane 1:</b></label>
                  <label><?php echo $data->lane1 ?></label>
                </div>
                <div class="form-group">
                  <label for="lane2"><b>Address Lane 2:</b></label>
                  <label><?php echo $data->lane2 ?></label>
                </div>
                <div class="form-group">
                  <label for="lane3"><b>Address Lane 3:</b></label>
                  <label><?php echo $data->lane3 ?></label>
                </div>
                <div class="form-group">
                  <label for="mob-no"><b>Mobile Number:</b></label>
                  <label><?php echo $data->telNo ?></label>
                </div>
                <div class="form-group">
                  <label for="home-no"><b>Home Number:</b></label>
                  <label><?php echo $data->lanNo ?></label>
                </div>
                <div class="form-group">
                  <label for="email"><b>Email:</b></label>
                  <label><?php echo $data->email ?></label>
                </div>
              </section>
              <section class="section_right">
                <div class="roles">
                  <div class="role">
                    <label for="employee_id"><b>Employee ID:</b></label>
                    <label><?php echo $data->id ?></label>
                  </div>
                  <div class="role">
                    <label for="role"><b>Role:</b></label>
                    <label><?php echo $data->role ?></label>
                  </div>
                  <div class="role">
                    <label for="adddate"><b>Add date:</b></label>
                    <label><?php echo $data->timestamp ?></label>
                  </div>
                </div>
              </section>
            </section>
          </form>

          <!--  -->
        </div>
      </div>
    </div>
  </body>
  <script>
    let bars = document.getElementById("bars");
    let panel = document.getElementById("panel");

    bars.addEventListener("click", () => {
      panel.classList.toggle("hide");
    });
  </script>
</html>

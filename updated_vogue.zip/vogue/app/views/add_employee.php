<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo URL_ROOT?>stylesheets/add_employee.css">
</head>

<body>
    <div class="page">
        <div class="right">
            <div class="right-heading">
                <div class="right-side">
                    <div class="back" id="back">
                        <a href="url"><img src="<?php echo URL_ROOT?>img/backbutton.png" alt="back"></a>
                    </div>
                    <h1>
                        Add New
                    </h1>
                </div>
                <img class="vogue" src="<?php echo URL_ROOT?>img/Panem Finance Inc 3.png" alt="logo">
            </div>
            <div class="content-add-new-page">
                <!--  -->
                <form action="<?php echo URL_ROOT?>staff/setStaffMember" method="POST">
                    <section class="section_left">
                        <section class="big-form">
                            <img src="<?php echo URL_ROOT?>img/image 1.png" alt="photo">

                            <div class="form-group">
                                <label for="fName"><b>First Name:</b></label>
                                <input type="text" placeholder="EX: Thimeth" name="fName" id="fName" required>
                            </div>
                            <div class="form-group">
                                <label for="lName"><b>Last Name:</b></label>
                                <input type="text" placeholder="EX: Imesha" name="lName" id="lName" required>
                            </div>
                            <div class="form-group">
                                <label for="nic"><b>NIC:</b></label>
                                <input type="text" placeholder="EX: 99012...V" name="nic" id="nic" required>
                            </div>
                            <div class="form-group">
                                <label for="dob"><b>Date of Birth:</b></label>
                                <input type="date" placeholder="EX: year/month/day" name="dob" id="dob" required>
                            </div>
                            <div class="form-group">
                                <label for="lane1"><b>Address Lane 1:</b></label>
                                <input type="text" placeholder="" name="lane1" id="lane1" required>
                            </div>
                            <div class="form-group">
                                <label for="lane2"><b>Address Lane 2:</b></label>
                                <input type="text" placeholder="" name="lane2" id="lane2" required>
                            </div>
                            <div class="form-group">
                                <label for="lane3"><b>Address Lane 3:</b></label>
                                <input type="text" placeholder="" name="lane3" id="lane3">
                            </div>
                            <div class="form-group">
                                <label for="mob-no"><b>Mobile Number:</b></label>
                                <input type="text" placeholder="EX: 07X-xxxxxxx" name="mob-no" id="mob-no" required>
                            </div>
                            <div class="form-group">
                                <label for="home-no"><b>Home Number:</b></label>
                                <input type="text" placeholder="" name="home-no" id="home-no" required>
                            </div>
                            <div class="form-group">
                                <label for="email"><b>Email:</b></label>
                                <input type="text" placeholder="EX:XXXXX@gmail.com" name="email" id="email" required>
                            </div>
                        </section>
                        <section class="section_right">
                            <div class="roles">
                                <label> Role :
                                </label>
                                <div class="role">
                                    <input type="radio" name="role" value="Pawning Officer"/><label> Pawning Officer </label>
                                </div>
                                <div class="role">
                                    <input type="radio" name="role" value="Gold Appraiser"/> <label>Gold Appraiser</label>
                                </div>
                                <div class="role">
                                    <input type="radio" name="role" value="Vault Keeper"/> <label>Vault Keeper </label>
                                </div>
                            </div>
                            <div class="two-btns">
                                <button type="submit" class="cancelbtn">Cancel</button>
                                <button type="submit" class="registerbtn">Add New</button>
                            </div>
                        </section>
                    </section>

                </form>

                <!--  -->
            </div>
        </div>
    </div>
</body>
<script>
    let bars = document.getElementById("bars");
    let panel = document.getElementById("panel");

    bars.addEventListener("click", () => {
        panel.classList.toggle("hide");
    })
</script>

</html>
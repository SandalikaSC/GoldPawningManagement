<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>LOGIN</title>
    <link rel="stylesheet" href="<?php echo URL_ROOT?>public/stylesheets/login.css">
  </head>
  <body>
    <div class="whole-login-form">
      <div class="left-side-of-login">
        <label class="label-welcome">Welcome</label>
        <label class="label-back-to"> Back to</label>
        <img src="<?php echo URL_ROOT?>img/Panem Finance Inc 3.png" alt="logo">
      </div>
      <div class="right-side-of-login">
        <div class="title-part">
          <span>L O G I N</span>
        </div>

        <form action="<?php echo URL_ROOT?>login/verify" method="post">
          <div class="input-field-part">
            <label for="uname"><b>Username</b></label>
            <input
              type="text"
              placeholder="Enter Username"
              name="uname"
              onfocus="this.value=''"
              required
            />

            <label for="psw"><b>Password</b></label>
            <input
              type="password"
              placeholder="Enter Password"
              name="psw"
              onfocus="this.value=''"
              pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
              title="Must contain at least one number and one uppercase and lowercase letter, and at least 3 or more characters"
              required
            />

            <button type="submit" id="manager-login-btn">Login</button>
            <label>
              <input type="checkbox" checked="checked" name="remember" />
              Remember me
            </label>
          </div>

          <div class="bot-div">
            <a href="#">Forgot password?</a>
          </div>
        </form>
      </div>
    </div>
  </body>
</html>

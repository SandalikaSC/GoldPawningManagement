<?php
// session_start();
// if(!isset($_SESSION["user"])){
//     header("location:login.php");
// }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff</title>
    <link rel="stylesheet" href="<?php echo URL_ROOT ?>public/stylesheets/staff_dashboard.css">
    <link rel="stylesheet" href="<?php echo URL_ROOT ?>public/stylesheets/staff_table.css">
</head>

<body>
    <?php 
    if(!empty($data[1])){
        include_once 'add-success.php';
    }
    ?>
    <div class="page">
        <div class="left" id="panel">
            <div class="profile">
                <div class="profile-pic">
                    <a href="url"><img src="<?php echo URL_ROOT ?>public/img/image 1.png" alt=""></a>
                </div>
                <div class="name">
                    <p>Thimeth Imesha</p>
                </div>
            </div>
            <div class="btn-set">
                <a href="url">
                    <img src="<?php echo URL_ROOT ?>public/img/dashboard.png" alt="">
                    <p>Dashboard</p>
                </a>
                <a href="url">
                    <img src="<?php echo URL_ROOT ?>public/img/locker.png" alt="">
                    <p>Locker</p>
                </a>
                <a href="url">
                    <img src="<?php echo URL_ROOT ?>public/img/pawned.png" alt="">
                    <p>Pawned Articles</p>
                </a>
                <a href="url">
                    <img src="<?php echo URL_ROOT ?>public/img/auction.png" alt="">
                    <p>Auction</p>
                </a>
                <a class="staf" href="url">
                    <img src="<?php echo URL_ROOT ?>public/img/golden_staff.png" alt="">
                    <p>Staff</p>
                </a>
            </div>
            <div class="lgout">
                <a href="<?php echo URL_ROOT ?>logout">Logout</a>
            </div>
        </div>
        <div class="right">
            <div class="right-heading">
                <div class="right-side">
                    <div class="bars" id="bars">
                        <img src="<?php echo URL_ROOT ?>public/img/icons8-bars-48.png" alt="bars">
                    </div>
                    <h1>
                        Staff
                    </h1>
                </div>
                <img class="vogue" src="<?php echo URL_ROOT ?>public/img/Panem Finance Inc 3.png" alt="logo">
            </div>
            <div class="inside-page">
                <div class="add-new-and-search">

                    <div class="search-bar">
                        <input type="text" name="" id="" placeholder="Search...">

                        <img src="<?php echo URL_ROOT ?>public/img/search-icon.png" alt="search-icon">

                    </div>
                    <div class="add-new-btn">
                        <a href="<?php echo URL_ROOT ?>staff/addNew">
                            <img src="<?php echo URL_ROOT ?>public/img/golden-plus.png" alt="plus">
                            <label for="add-new-btn">Add New</label>
                        </a>
                    </div>

                </div>
                <div class="table">
                    <div class="table-section">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Role</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($data[0] != 0) {
                                    foreach ($data[0] as $row) {
                                        echo "
                                            <tr>
                                                <td>" . $row->id . "</td>
                                                <td>" . $row->Name . "</td>
                                                <td>" . $row->role . "</td>
                                                <td>" . $row->date . "</td>
                                                <td>
                                                    <a href='".URL_ROOT."staff/viewStaffMember/".$row->id."'>View</a>
                                                    <button>Delete</button>
                                                </td>
                                            </tr>";
                                    }
                                } else {
                                    echo "NO Data";
                                }
                                ?>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
<script>
    let bars = document.getElementById("bars");
    let panel = document.getElementById("panel");

    bars.addEventListener("click", () => {
        panel.classList.toggle("hide");
    })
</script>

</html>
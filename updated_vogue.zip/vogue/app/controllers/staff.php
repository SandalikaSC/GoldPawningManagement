<?php
   class Staff extends Controller{
    public function index($msg=null){
        isLoggedIn();
        $staff = $this->model("staffModel");
        $result = $staff->getStaffMember();
        $this->view("staff_dashboard",array($result,$msg));
    }

    
    public function addNew(){
      isLoggedIn();
      $this->view("add_employee");
    }

    private function randomPassword() {
      $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
      $pass = array(); //remember to declare $pass as an array
      $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
      for ($i = 0; $i < 8; $i++) {
          $n = rand(0, $alphaLength);
          $pass[] = $alphabet[$n];
      }
      return implode($pass); //turn the array into a string
    }

    public function setStaffMember(){
      isLoggedIn();
      $staffMem=$this->model("staffModel");
      $result=$staffMem->addStaffMember($_POST['fName'], $_POST['lName'],$_POST['nic'],$_POST['dob'],$_POST['lane1'],$_POST['lane2'],$_POST['lane3'],$_POST['mob-no'],$_POST['home-no'],$_POST['email'],$_POST['role']);

      if($result){
        $randPassword=$this->randomPassword();
        sendMail($_POST['email'],$randPassword, $_POST['fName']. $_POST['lName']);
        redirect('staff/index/success');
      }else{
        redirect('staff/addNew');
      }
    }

    public function viewStaffMember($id){
       isLoggedIn();
       $staffMem=$this->model("staffModel");
       $result=$staffMem->viewStaffMember($id);
       $this->view("view-employee",$result);
    }

  }
?>
<?php

class Users extends Controller{
    public function index(){
        $this->view("index");
    }
}

?>
<?php

class Login extends Controller
{
    public function index()
    {

        if (isset($_SESSION['user'])) {
            redirect('dashboard');
        }

        $this->view("login");
    }

    public function verify()
    {

        if (isset($_POST["uname"]) and isset($_POST["psw"])) {
            $email = $_POST["uname"];
            $pass = $_POST["psw"];
            $user = $this->model("UserModel");
            $result = $user->getUser($email);
            if ($user->rowCount() > 0) {
                // output data of each row
                $res = $result->password;
                if ($res == $pass) {
                    $_SESSION["user"] = $email;
                    header("location:" . URL_ROOT . "dashboard");
                } else {
                    header("location:" . URL_ROOT . "login");
                }
            } else {
                header("location:" . URL_ROOT . "login");
            }
        }
    }
}

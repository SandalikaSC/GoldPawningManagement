<?php

/** App Root */
define('APP_ROOT', dirname(dirname(__FILE__)));

/** URL Root */
const URL_ROOT = 'http://localhost/vogue/';

/** Site Name */
// const SITE_NAME = 'PawnSystem';

/** Database */
const DB_HOST = 'localhost';
const DB_USER = 'root';
const DB_PASS = '';
const DB_NAME = 'auction_articles';

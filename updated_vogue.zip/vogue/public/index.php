<?php

require_once '../app/boot.php';

//Init CORE Library

$init = new Core();